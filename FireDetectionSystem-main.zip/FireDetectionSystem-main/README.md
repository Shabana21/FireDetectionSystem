# FireDetectionSystem
The Fire Detection System is designed to identify and alert occupants about the presence of a fire. This system consists of a Flame sensor, Arduino Nano and Buzzer that work together to detect a fire emergency.
